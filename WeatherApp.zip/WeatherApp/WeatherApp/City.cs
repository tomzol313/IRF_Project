﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherApp
{
    class City
    {
        public string varos { get; set; }
        public decimal lat { get; set; }
        public decimal lng { get; set; }
    }
}

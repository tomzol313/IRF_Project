A program egy webszolgáltatásra épül, amellyel megjeleníthetőek az aktuális időjárási adatok. 
A felhasználó elsősorban kiválaszthatja, hogy melyik amerikai város értékeire kíváncsi. 
A felhasználó rászűrhet néhány adatra is, amiket meg szeretne jeleníteni, továbbá a hőmérsékletre vonatkozó adatokat megjelenítheti Celsius vagy Fahrenheit értékként is.
A kinyert adatokat le is töltheti egy CSV fájlba. 
A program az adott időjáráshoz illő képet fogja majd megjeleníteni a graphics osztály segíségével.